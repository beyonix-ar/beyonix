"use client"

import { Slider } from "@/components/ui/slider"

interface PriceFilterProps {
  minPrice: number
  maxPrice: number
  setMinPrice: (value: number) => void
  setMaxPrice: (value: number) => void
}

export function PriceFilter({
  minPrice,
  maxPrice,
  setMinPrice,
  setMaxPrice,
}: PriceFilterProps) {
  return (
    <div className="mb-8">
      <p className="mb-4 text-sm font-semibold text-white">
        Rango de precio
      </p>

      <Slider
        value={[minPrice, maxPrice]}
        min={1000}
        max={150000}
        step={1000}
        minStepsBetweenThumbs={1}
        onValueChange={(value) => {
          setMinPrice(value[0])
          setMaxPrice(value[1])
        }}
        className="w-full"
      />

      <div className="mt-3 flex justify-between text-xs text-white">
        <span>${minPrice.toLocaleString("es-AR")}</span>
        <span>${maxPrice.toLocaleString("es-AR")}</span>
      </div>
    </div>
  )
}