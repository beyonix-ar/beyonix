"use client"

interface CommerceFilterProps {
  onlyOffers: boolean
  setOnlyOffers: (value: boolean) => void
  onlyBestSellers: boolean
  setOnlyBestSellers: (value: boolean) => void
  onlyNew: boolean
  setOnlyNew: (value: boolean) => void
}

export function CommerceFilter({
  onlyOffers,
  setOnlyOffers,
  onlyBestSellers,
  setOnlyBestSellers,
  onlyNew,
  setOnlyNew,
}: CommerceFilterProps) {
  return (
    <div className="mb-8">
      <p className="mb-4 text-sm font-semibold text-white">
        Estado comercial
      </p>

      <div className="space-y-3">
        <label className="flex items-center gap-3 text-sm text-white/80">
          <input
            type="checkbox"
            checked={onlyOffers}
            onChange={(e) =>
              setOnlyOffers(e.target.checked)
            }
            className="size-4"
          />
          En oferta
        </label>

        <label className="flex items-center gap-3 text-sm text-white/80">
          <input type="checkbox" className="size-4" />
          Cuotas sin interés
        </label>

        <label className="flex items-center gap-3 text-sm text-white/80">
          <input
            type="checkbox"
            checked={onlyBestSellers}
            onChange={(e) =>
              setOnlyBestSellers(e.target.checked)
            }
            className="size-4"
          />
          Más vendidos
        </label>

        <label className="flex items-center gap-3 text-sm text-white/80">
          <input
            type="checkbox"
            checked={onlyNew}
            onChange={(e) =>
              setOnlyNew(e.target.checked)
            }
            className="size-4"
          />
          Nuevos ingresos
        </label>
      </div>
    </div>
  )
}