"use client"

import { productColors } from "@/lib/product-colors"

interface ColorFilterProps {
  selectedColors: string[]
  availableColors: string[]
  onToggleColor: (color: string) => void
}

export function ColorFilter({
  selectedColors,
  availableColors,
  onToggleColor,
}: ColorFilterProps) {
  return (
    <div>
      <p className="mb-4 text-sm font-semibold text-white">
        Colores
      </p>

      <div className="flex flex-wrap gap-3">
        {availableColors.map((colorKey) => {
          const colorClass =
            productColors[
              colorKey as keyof typeof productColors
            ] || "bg-gray-500"

          return (
            <button
              key={colorKey}
              type="button"
              onClick={() => onToggleColor(colorKey)}
              aria-label={`Color ${colorKey}`}
              className={`size-7 rounded-full p-0.5 border transition-all duration-200 cursor-pointer ${colorClass} ${
                selectedColors.includes(colorKey)
                  ? "border-white ring-2 ring-white ring-offset-2 ring-offset-black shadow-[0_0_12px_rgba(255,255,255,0.35)]"
                  : "border-white/30 hover:border-white/60"
              }`}
            />
          )
        })}
      </div>
    </div>
  )
}