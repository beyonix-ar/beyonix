"use client"

interface CategoryFilterProps {
  selectedCategories: string[]
  setSelectedCategories: (value: string[]) => void
}

export function CategoryFilter({
  selectedCategories,
  setSelectedCategories,
}: CategoryFilterProps) {
  const toggleCategory = (category: string) => {
    if (selectedCategories.includes(category)) {
      setSelectedCategories(
        selectedCategories.filter((item) => item !== category)
      )
      return
    }

    setSelectedCategories([
      ...selectedCategories,
      category,
    ])
  }

  return (
    <div className="mb-8">
      <p className="mb-4 text-sm font-semibold text-white">
        Categorías
      </p>

      <div className="space-y-3">
        <label className="flex items-center gap-3 text-sm text-white/80">
          <input
            type="checkbox"
            checked={selectedCategories.includes("audio-conectividad")}
            onChange={() =>
              toggleCategory("audio-conectividad")
            }
            className="size-4"
          />
          Audio y conectividad
        </label>

        <label className="flex items-center gap-3 text-sm text-white/80">
          <input
            type="checkbox"
            checked={selectedCategories.includes("confort-bienestar")}
            onChange={() =>
              toggleCategory("confort-bienestar")
            }
            className="size-4"
          />
          Confort y bienestar
        </label>

        <label className="flex items-center gap-3 text-sm text-white/80">
          <input
            type="checkbox"
            checked={selectedCategories.includes("setup-escritorio")}
            onChange={() =>
              toggleCategory("setup-escritorio")
            }
            className="size-4"
          />
          Setup y escritorio
        </label>
      </div>
    </div>
  )
}