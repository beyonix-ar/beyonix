"use client"

import { productColors } from "@/lib/product-colors"
import type { ProductItem } from "@/components/products/product-details"

interface ProductCardColorsProps {
  colors: ProductItem["colors"]
  selectedIndex: number
  onSelectColor: (index: number) => void
}

export function ProductCardColors({
  colors,
  selectedIndex,
  onSelectColor,
}: ProductCardColorsProps) {
  if (!colors?.length) return null

  return (
    <div className="mt-3 flex flex-wrap gap-2">
      {colors.map((color, index) => (
        <button
          key={color.value}
          type="button"
          onClick={() => onSelectColor(index)}
          aria-label={`Color ${color.name}`}
          className={`size-5 rounded-full border transition-all cursor-pointer ${
            productColors[
              color.value as keyof typeof productColors
            ] || "bg-white"
          } ${
            selectedIndex === index
              ? "border-white ring-2 ring-white/70"
              : "border-white/20"
          }`}
        />
      ))}
    </div>
  )
}