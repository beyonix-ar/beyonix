"use client"

import { ProductCartToggleButton } from "@/components/products/product-cart-toggle-button"

interface ProductCardPricingProps {
  price: number
  originalPrice?: number
  discountPercentage?: number | null

  quantity: number

  onAddToCart?: () => void
  onIncrease?: () => void
  onDecrease?: () => void
}

export function ProductCardPricing({
  price,
  originalPrice,
  discountPercentage,

  quantity,

  onAddToCart,
  onIncrease,
  onDecrease,
}: ProductCardPricingProps) {
  return (
    <div
      onClick={(e) => e.stopPropagation()}
      className="pt-3"
    >
      <div className="space-y-1">
        <div className="flex items-center gap-2">
          <p className="text-xl font-medium tracking-tight text-white font-sans">
            ${price.toLocaleString("es-AR")}
          </p>

          {discountPercentage && (
            <span className="rounded-md bg-green-500/15 px-2 py-0.5 text-sm font-semibold text-green-400 shadow-md">
              -{discountPercentage}%
            </span>
          )}
        </div>

        {originalPrice && originalPrice > price && (
          <p className="font-sans text-sm text-white/40 line-through">
            ${originalPrice.toLocaleString("es-AR")}
          </p>
        )}
      </div>

      <div className="mt-5 relative z-10">
        <ProductCartToggleButton
          quantity={quantity}
          onAdd={() => {
            onAddToCart?.()
          }}
          onIncrease={() => {
            onIncrease?.()
          }}
          onDecrease={() => {
            onDecrease?.()
          }}
        />
      </div>
    </div>
  )
}