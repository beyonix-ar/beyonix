"use client"

import { useMemo, useState, useEffect } from "react"
import type { ProductItem } from "@/components/products/product-details"
import { ProductCardImage } from "./product-card-image"
import { ProductCardColors } from "./product-card-colors"
import { ProductCardPricing } from "./product-card-pricing"
import { useCart } from "@/context/cart-context"

interface SharedProductCardProps {
  product: ProductItem
  selectedColors?: string[]
  onOpenPreview?: (product: ProductItem & { initialColor?: string }) => void
  onAddToCart?: (
    product: ProductItem,
    color: string,
    image?: string
  ) => void
}

export default function SharedProductCard({
  product,
  selectedColors = [],
  onOpenPreview,
  onAddToCart,
}: SharedProductCardProps) {

  const {
    getQuantity,
    increaseQuantity,
    decreaseQuantity,
  } = useCart()

  const initialColorIndex = useMemo(() => {
    if (!product.colors?.length || selectedColors.length === 0) return 0

    const index = product.colors.findIndex((color) =>
      selectedColors.includes(color.name.trim().toLowerCase())
    )

    return index >= 0 ? index : 0
  }, [product, selectedColors])

  const [selectedColorIndex, setSelectedColorIndex] =
    useState(initialColorIndex)

  const [selectedImageIndex, setSelectedImageIndex] =
    useState(0)

  useEffect(() => {
    if (!product.colors?.length) return

    if (selectedColors.length === 0) {
      setSelectedColorIndex(0)
      return
    }

    const index = product.colors.findIndex((color) =>
      selectedColors.includes(color.name.trim().toLowerCase())
    )

    if (index >= 0) {
      setSelectedColorIndex(index)
      setSelectedImageIndex(0)
    }
  }, [selectedColors, product.colors])

  const activeColor =
    product.colors?.[selectedColorIndex] ?? product.colors?.[0]

  const quantity = activeColor?.name
    ? getQuantity(product.id, activeColor.name)
    : 0

  const activeImages =
    activeColor?.images?.length
      ? activeColor.images
      : ["/placeholder.png"]

  const currentImage =
    activeImages[selectedImageIndex] || activeImages[0]

  const discountPercentage =
    product.originalPrice && product.originalPrice > product.price
      ? Math.round((1 - product.price / product.originalPrice) * 100)
      : null

  const goPrevImage = () => {
    setSelectedImageIndex((prev) =>
      prev === 0 ? activeImages.length - 1 : prev - 1
    )
  }

  const goNextImage = () => {
    setSelectedImageIndex((prev) =>
      prev === activeImages.length - 1 ? 0 : prev + 1
    )
  }

  const handleSelectColor = (index: number) => {
    setSelectedColorIndex(index)
    setSelectedImageIndex(0)
  }

  const handleAddToCart = () => {
    if (!onAddToCart || !activeColor?.name) return

    onAddToCart(
      product,
      activeColor.name,
      currentImage
    )
  }

  return (
    <article className="overflow-hidden rounded-xl border border-white/10 bg-black">
      <ProductCardImage
        image={currentImage}
        canNavigate={activeImages.length > 1}
        onPrev={goPrevImage}
        onNext={goNextImage}
        productName={product.name}
        onOpenPreview={() =>
          onOpenPreview?.({
            ...product,
            initialColor: activeColor?.name,
          })
        }
      />

      <div className="flex h-265px flex-col p-4">
        <p className="mb-2 text-xs uppercase tracking-[0.18em] text-white/50">
          {product.category}
        </p>

        <h3 className="min-h-56px line-clamp-2 text-lg font-semibold leading-7 text-white">
          {product.name}
        </h3>

        {product.colors?.length > 0 && (
          <ProductCardColors
            colors={product.colors}
            selectedIndex={selectedColorIndex}
            onSelectColor={handleSelectColor}
          />
        )}

        <div className="mt-auto">
          <ProductCardPricing
            price={product.price}
            originalPrice={product.originalPrice}
            discountPercentage={discountPercentage}

            quantity={quantity}

            onAddToCart={handleAddToCart}

            onIncrease={() => {
              if (!activeColor?.name) return

              increaseQuantity(
                product.id,
                activeColor.name
              )
            }}

            onDecrease={() => {
              if (!activeColor?.name) return

              decreaseQuantity(
                product.id,
                activeColor.name
              )
            }}
          />
        </div>
      </div>
    </article>
  )
}