"use client"

import { ChevronLeft, ChevronRight } from "lucide-react"

interface ProductCardImageProps {
  image: string
  canNavigate: boolean
  onPrev: () => void
  onNext: () => void
  productName: string
  onOpenPreview?: () => void
}

export function ProductCardImage({
  image,
  canNavigate,
  onPrev,
  onNext,
  productName,
  onOpenPreview,
}: ProductCardImageProps) {
  return (
    <div
      onClick={onOpenPreview}
      className="relative aspect-square overflow-hidden bg-white cursor-pointer"
    >
      <img
        src={image}
        alt={productName}
        className="h-full w-full object-cover transition-transform duration-300 hover:scale-105"
      />

      {canNavigate && (
        <>
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation()
              onPrev()
            }}
            aria-label="Imagen anterior"
            className="absolute left-0.5 top-1/2 z-10 flex size-7 -translate-y-1/2 items-center justify-center rounded-full bg-[#16304F] text-white shadow-lg transition hover:scale-105 cursor-pointer"
          >
            <ChevronLeft className="size-4" />
          </button>

          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation()
              onNext()
            }}
            aria-label="Imagen siguiente"
            className="absolute right-0.5 top-1/2 z-10 flex size-7 -translate-y-1/2 items-center justify-center rounded-full bg-[#16304F] text-white shadow-lg transition hover:scale-105 cursor-pointer"
          >
            <ChevronRight className="size-4" />
          </button>
        </>
      )}
    </div>
  )
}