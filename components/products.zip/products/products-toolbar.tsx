"use client"

import { useState, useRef, useEffect } from "react"

interface ProductsToolbarProps {
  total: number
  sortBy: string
  setSortBy: (value: string) => void
}

export function ProductsToolbar({
  total,
  sortBy,
  setSortBy,
}: ProductsToolbarProps) {
  const [open, setOpen] = useState(false)
  const containerRef = useRef<HTMLDivElement>(null)

  const options = [
    { label: "Relevancia", value: "relevance" },
    { label: "Menor precio", value: "price-asc" },
    { label: "Mayor precio", value: "price-desc" },
  ]

  const selected =
    options.find((o) => o.value === sortBy)?.label ||
    "Relevancia"

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (
        containerRef.current &&
        !containerRef.current.contains(event.target as Node)
      ) {
        setOpen(false)
      }
    }

    document.addEventListener("mousedown", handleClickOutside)

    return () => {
      document.removeEventListener("mousedown", handleClickOutside)
    }
  }, [])

  return (
    <div className="mb-6 flex items-center justify-between rounded-xl border border-white/10 bg-black p-4">
      <div>
        <p className="text-base text-white/60">Mostrando</p>
        <p className="text-lg font-semibold text-white">
          {total} productos
        </p>
      </div>

      <div ref={containerRef} className="relative">
        {/* BOTÓN */}
        <button
          type="button"
          aria-label="Ordenar productos"
          title="Ordenar"
          onClick={() => setOpen(!open)}
          className="flex items-center gap-2 rounded-lg border border-white/10 bg-black px-4 py-2 text-sm text-white cursor-pointer"
        >
          {selected}
          <span className="text-white/60">▼</span>
        </button>

        {/* DROPDOWN */}
        {open && (
          <div className="absolute left-0 mt-2 w-40 rounded-lg border border-white/10 bg-black shadow-lg z-50">
            {options.map((option) => (
              <button
                key={option.value}
                type="button"
                aria-label={`Ordenar por ${option.label}`}
                title={option.label}
                onClick={() => {
                  setSortBy(option.value)
                  setOpen(false)
                }}
                className="w-full text-left px-4 py-2 text-sm text-white hover:bg-white/20 cursor-pointer"
              >
                {option.label}
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}