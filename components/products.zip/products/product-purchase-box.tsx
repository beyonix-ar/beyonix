"use client"

import { useState } from "react"
import { ProductCartToggleButton } from "./product-cart-toggle-button"

interface ProductPurchaseBoxProps {
  price: number
  originalPrice?: number
  isInCart?: boolean
  onAddToCart: (quantity?: number) => void
  onRemoveFromCart: () => void
  onViewCart: () => void
}

function formatPrice(price: number) {
  return new Intl.NumberFormat("es-AR", {
    style: "currency",
    currency: "ARS",
    minimumFractionDigits: 0,
  }).format(price)
}

export function ProductPurchaseBox({
  price,
  originalPrice,
  isInCart = false,
  onAddToCart,
  onRemoveFromCart,
  onViewCart,
}: ProductPurchaseBoxProps) {
  const [quantity, setQuantity] = useState(isInCart ? 1 : 0)

  const handleAdd = () => {
    setQuantity(1)
    // ✅ FIX: pasa quantity=1 al agregar por primera vez
    onAddToCart(1)
  }

  const handleIncrease = () => {
    const next = quantity + 1
    setQuantity(next)
    // ✅ FIX: agrega 1 unidad más al carrito
    onAddToCart(1)
  }

  const handleDecrease = () => {
    if (quantity === 1) {
      setQuantity(0)
      onRemoveFromCart()
    } else {
      setQuantity((q) => q - 1)
      onRemoveFromCart()
    }
  }

  const discount =
    originalPrice && originalPrice > price
      ? Math.round(((originalPrice - price) / originalPrice) * 100)
      : null

  return (
    <div className="px-8 py-5">

      <div className="mb-4 flex items-baseline gap-2.5">
        <span className="text-[22px] font-bold tracking-tight text-white leading-none">
          {formatPrice(price)}
        </span>

        {discount && (
          <span className="text-[14px] font-semibold text-emerald-400 bg-emerald-500/[0.12] border border-emerald-500/25 px-1.5 py-0.5 rounded leading-none">
            -{discount}%
          </span>
        )}

        {originalPrice && originalPrice > price && (
          <span className="text-[14px] text-white/65 line-through leading-none">
            {formatPrice(originalPrice)}
          </span>
        )}
      </div>

      <div className="space-y-2">
        <ProductCartToggleButton
          quantity={quantity}
          onAdd={handleAdd}
          onIncrease={handleIncrease}
          onDecrease={handleDecrease}
        />

        <button
          type="button"
          aria-label="Ver carrito"
          title="Ver carrito"
          onClick={onViewCart}
          className="w-full h-10 rounded-md border border-white/15 bg-white/[0.05] text-[14px] font-medium text-white/75 transition-colors hover:bg-white/[0.09] hover:text-white/85 hover:border-white/25 cursor-pointer"
        >
          Ver carrito
        </button>
      </div>
    </div>
  )
}