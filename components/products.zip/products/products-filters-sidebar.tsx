"use client"

import { CommerceFilter } from "./filters/commerce-filter"
import { PriceFilter } from "./filters/price-filter"
import { CategoryFilter } from "./filters/category-filter"
import { ColorFilter } from "./filters/color-filter"

interface ProductsFiltersSidebarProps {
  selectedCategories: string[]
  setSelectedCategories: (value: string[]) => void
  selectedColors: string[]
  setSelectedColors: (value: string[]) => void
  availableColors: string[]

  onlyOffers: boolean
  setOnlyOffers: (value: boolean) => void

  onlyBestSellers: boolean
  setOnlyBestSellers: (value: boolean) => void
  onlyNew: boolean
  setOnlyNew: (value: boolean) => void

  minPrice: number
  setMinPrice: (value: number) => void
  maxPrice: number
  setMaxPrice: (value: number) => void
}

export function ProductsFiltersSidebar({
  selectedCategories,
  setSelectedCategories,
  selectedColors,
  setSelectedColors,
  availableColors,

  onlyOffers,
  setOnlyOffers,

  onlyBestSellers,
  setOnlyBestSellers,
  onlyNew,
  setOnlyNew,

  minPrice,
  setMinPrice,
  maxPrice,
  setMaxPrice,
}: ProductsFiltersSidebarProps) {
  const toggleColor = (color: string) => {
    if (selectedColors.includes(color)) {
      setSelectedColors(
        selectedColors.filter((item) => item !== color)
      )
      return
    }

    setSelectedColors([...selectedColors, color])
  }

  return (
    <aside className="h-fit rounded-xl border border-white/10 bg-[#111111] p-5">
      <div className="mb-6">
        <h3 className="text-sm font-semibold uppercase tracking-[0.2em] text-white/60">
          Filtros
        </h3>
      </div>

      <CommerceFilter
        onlyOffers={onlyOffers}
        setOnlyOffers={setOnlyOffers}
        onlyBestSellers={onlyBestSellers}
        setOnlyBestSellers={setOnlyBestSellers}
        onlyNew={onlyNew}
        setOnlyNew={setOnlyNew}
      />

      <PriceFilter
        minPrice={minPrice}
        maxPrice={maxPrice}
        setMinPrice={setMinPrice}
        setMaxPrice={setMaxPrice}
      />

      <CategoryFilter
        selectedCategories={selectedCategories}
        setSelectedCategories={setSelectedCategories}
      />

      <ColorFilter
        selectedColors={selectedColors}
        availableColors={availableColors}
        onToggleColor={toggleColor}
      />
    </aside>
  )
}